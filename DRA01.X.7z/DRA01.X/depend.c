#include "xc.h"
#include <stdlib.h>
#include "depend.h"
extern uint16_t FBmin, FBmax;
////////////////////////////////////////////////////////////////////////////////
unsigned int DoubleToINT(double value){
unsigned int variable;
variable = (int)value;
value -= variable;
if(value>=0.5)variable++;
return variable;
}//
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
unsigned int adc_to_int(int dat_adc, int diap, char kis){
double K_diap, B_diap, dat_tmp;
const int adc_20mA = 2500;
const int adc_4mA = 495;

K_diap = (double)diap/(adc_20mA - adc_4mA);
B_diap = K_diap * adc_4mA;
dat_tmp =(K_diap * dat_adc) - B_diap;
if(dat_tmp < 0)dat_tmp = 0;
if(kis > 0)dat_tmp = 0;
return DoubleToINT(dat_tmp);
}//
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
int define_FB(int R)
{
double diap, k1, b1, tmp_ang;
int ANGLE;
//const int Rmax = 4036;
//const int Rmin = 490;
uint16_t Rmax;
uint16_t Rmin;

Rmax = FBmax;
Rmin = FBmin;
diap = (double)abs(Rmax - Rmin);
k1 = 100.0/diap;
b1 = k1 * Rmax - 100.0;
tmp_ang = k1 * R - b1;
ANGLE = (int)tmp_ang;

if(ANGLE > 100)ANGLE = 100;
if(ANGLE < 0)ANGLE = 0;

return ANGLE;
}//
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////