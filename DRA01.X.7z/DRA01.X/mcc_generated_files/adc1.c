/**
  Section: Included Files
*/

#include "adc1.h"
#include "pin_manager.h"
#include "delay.h"
#include "../depend.h"

#define MAX_CHNUM       10          // Highest Analog input number in Channel Scan
#define SAMP_BUFF_SIZE  8           // Size of the input buffer per analog input
#define NUM_CHS2SCAN    5           // Number of channels enabled for channel scan

/**
  Section: File Specific Functions
*/
uint16_t Rset, datFB, FB, datIset, Iset, I_load, Upower;

uint16_t   bufferA[MAX_CHNUM + 1][SAMP_BUFF_SIZE] __attribute__( (space(xmemory), aligned(256)) );
uint16_t   bufferB[MAX_CHNUM + 1][SAMP_BUFF_SIZE] __attribute__( (space(xmemory), aligned(256)) );

//+ DMA0_BUFFER_LEN * sizeof(unsigned int)
// dmaBuffer variable is used to toggle the buffer between A and B for copying.
uint16_t    dmaBuffer = 1;
//Function Prototype
void ProcessAdj( __eds__ uint16_t *adcBuffer);
void ProcessUpower( __eds__ uint16_t *adcBuffer);
void ProcessFBposition( __eds__ uint16_t *adcBuffer);
void ProcessCurrentLoad( __eds__ uint16_t *adcBuffer);
void ProcessIset (__eds__ uint16_t *adcBuffer);

/**
  Section: Driver Interface
*/

void ADC1_Initialize (void)
{
    AD1CON1bits.FORM = 0;                       // Data Output Format: Signed Fraction (Q15 format)
    AD1CON1bits.SSRC = 2;                       // Sample Clock Source: GP Timer starts conversion
    AD1CON1bits.ASAM = 1;                       // ADC Sample Control: Sampling begins immediately after conversion
    AD1CON1bits.AD12B = 1;                      // 10-bit ADC operation
    AD1CON2bits.CSCNA = 1;                      // Scan Input Selections for CH0+ during Sample A bit
    AD1CON2bits.CHPS = 0;                       // Converts CH0
    AD1CON3bits.ADRC = 8;                       // ADC Clock is derived from Systems Clock
    AD1CON3bits.ADCS = 62;                      // ADC Conversion Clock Tad=Tcy*(ADCS+1)= (1/40M)*64 = 1.6us (625Khz)
    AD1CON2bits.VCFG = 1;
    // ADC Conversion Time for 10-bit Tc=12*Tab = 19.2us
    AD1CON1bits.ADDMABM = 0;                    // DMA buffers are built in scatter/gather mode
    AD1CON2bits.SMPI = ( NUM_CHS2SCAN - 1 );    // 4 ADC Channel is scanned
    AD1CON4bits.DMABL = 3;                      // Each buffer contains 8 words
    AD1CON4bits.ADDMAEN = 1;                    // Conversion results stored in ADCxBUF0 register
    
    //Assign Default Callbacks
    IFS0bits.AD1IF = 0;     // Clear the A/D interrupt flag bit
    IEC0bits.AD1IE = 0;     // Do Not Enable A/D interrupt

    
    AD1CSSH = 0x0000;
    AD1CSSLbits.CSS9  = 1;                       // Enable AN9 for channel scan
    AD1CSSLbits.CSS10 = 1;                       // Enable AN10 for channel scan
    AD1CSSLbits.CSS0  = 1;                       // Enable AN0 for channel scan
    AD1CSSLbits.CSS1 = 1;                       // Enable AN1 for channel scan
    AD1CSSLbits.CSS6  = 1;                       // Enable AN6 for channel scan
    
    TRISAbits.TRISA11 = 1;
    TRISAbits.TRISA12 = 1;
    TRISAbits.TRISA0 = 1;
    TRISAbits.TRISA1 = 1;
    TRISCbits.TRISC0 = 1;
    
    ANSELAbits.ANSA11 = 1;
    ANSELAbits.ANSA12 = 1;
    ANSELAbits.ANSA0 = 1;
    ANSELAbits.ANSA1 = 1;
    ANSELCbits.ANSC0 = 1;

    
    DMA2CONbits.AMODE = 2;  // Configure DMA for Peripheral indirect mode
    DMA2CONbits.MODE  = 2;   // Configure DMA for Continuous Ping-Pong mode
    DMA2PAD = ( int ) &ADC1BUF0;
    DMA2CNT = ( SAMP_BUFF_SIZE * NUM_CHS2SCAN ) - 1;
    DMA2REQ = 13;           // Select ADC1 as DMA Request source

    DMA2STAL = ( uint16_t ) ( &bufferA );
    DMA2STAH = ( uint16_t ) ( &bufferA );

    DMA2STBL = ( uint16_t ) ( &bufferB );
    DMA2STBH = ( uint16_t ) ( &bufferB );
   
    IFS1bits.DMA2IF  = 0;    //Clear the DMA interrupt flag bit
    IEC1bits.DMA2IE  = 1;    //Set the DMA interrupt enable bit
    DMA2CONbits.CHEN = 1;   // Enable DMA

DELAY_milliseconds(1);
AD1CON1bits.ADON = 0;// Turn off the ADC
DELAY_milliseconds(1);
AD1CON1bits.ADON = 1;// Turn on the ADC
DELAY_milliseconds(1);
AD1CON1bits.ADON = 0;// Turn off the ADC
DELAY_milliseconds(1);
AD1CON1bits.ADON = 1;// Turn on the ADC
DELAY_milliseconds(1);
AD1CON1bits.ADON = 1;// Turn on the ADC
DELAY_milliseconds(1);
   
}
////////////////////////////////////////////////////////////////////////////////
/******************************************************************************
 * Function:        void __attribute__((interrupt, auto_psv)) _DMA0Interrupt(void)
 * Overview:        Process the data in buffer A or in buffer B by invoking ProcessADCSamples function
 *****************************************************************************/
void __attribute__ ( ( interrupt, auto_psv ) ) _DMA2Interrupt( void )
{

    if( dmaBuffer == 1 )
    {
        
    ProcessAdj (&bufferA[6][0]);
    ProcessUpower (&bufferA[10][0]);
    ProcessFBposition (&bufferA[9][0]);
    ProcessCurrentLoad (&bufferA[1][0]);
    ProcessIset (&bufferA[0][0]);
        
    }
    else
    {

    ProcessAdj (&bufferB[6][0]);
    ProcessUpower (&bufferB[10][0]);
    ProcessFBposition (&bufferB[9][0]);
    ProcessCurrentLoad (&bufferB[1][0]);
    ProcessIset (&bufferB[0][0]);
    
    }
    
    HL_on_Toggle();
    
    dmaBuffer ^= 1;

    IFS1bits.DMA2IF = 0;    // Clear the DMA0 Interrupt Flag
}//
//******************************************************************************
//******************************************************************************
//******************************************************************************
//******************************************************************************
void ProcessIset (__eds__ uint16_t *adcBuffer )
{
    uint16_t ADCValue;
    int count;
    double	dtmp;
    
    ADCValue = 0;
  
    for (count = 0; count < 8; count++)    
	{                                     
        ADCValue += adcBuffer[count];
	}                             
   datIset = ADCValue/8;
   //y=0.04555808656036447x?24.41913439635536
   dtmp = 0.04555808656036447 * datIset - 24.41913439635536;
   if(dtmp < 0.1) dtmp = 0;
   if(dtmp > 99.6)dtmp = 100.0;
   Iset = (uint16_t)dtmp;
}//
////////////////////////////////////////////////////////////////////////////////
void ProcessCurrentLoad( __eds__ uint16_t *adcBuffer )
{
    uint16_t ADCValue, itmp;
    int count;
    double	dtmp;
    
    ADCValue = 0;
  
    for (count = 0; count < 8; count++)    
	{                                     
        ADCValue += adcBuffer[count];
	}                             
   itmp = ADCValue/8;
   //y= 24985 - 7.2752 * x
   dtmp = 24985.0 - 7.2752 * itmp;
   if(dtmp < 0.1) dtmp = 0;
   if(dtmp > 9990.0)dtmp = 9990.0;
   I_load = (int)dtmp; 
}//
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
void ProcessFBposition( __eds__ uint16_t *adcBuffer )
{
    uint16_t ADCValue;
    int count;
    
    ADCValue = 0;
  
    for (count = 0; count < 8; count++)    
	{                                     
        ADCValue += adcBuffer[count];
	}                             
   datFB = ADCValue/8;
   FB = define_FB(datFB);
}//
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
void ProcessUpower( __eds__ uint16_t *adcBuffer )
{
    uint16_t ADCValue, utmp;
    int count;
    double	dtmp;
    
    ADCValue = 0;
  
    for (count = 0; count < 8; count++)    
	{                                     
        ADCValue += adcBuffer[count];
	}                             
   utmp = ADCValue/8;
   //y= 0.1375*x + 9.2149
   dtmp = 0.1375 * (double)utmp + 9.2149;
   if(dtmp < 4.1) dtmp = 0;
   if(dtmp > 999.0)dtmp = 999.0;
   Upower = (int)dtmp;    
}//
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
void ProcessAdj( __eds__ uint16_t *adcBuffer )
{
    uint16_t ADCValue;		
    int count;
    double	dtmp;
    
    ADCValue = 0;
  
    for (count = 0; count < 8; count++)    
	{                                     
        ADCValue += adcBuffer[count];
	}                           
    //y=?0.07518796992481203x+100
    dtmp = 100.0 - (double)(ADCValue/8.0) * 0.0751879;
   if(dtmp < 0.1) dtmp = 0.0;
   if(dtmp > 99.8)dtmp = 100.0;    
   Rset = (int)dtmp;    
}//
////////////////////////////////////////////////////////////////////////////////
/**
  End of File
*/

