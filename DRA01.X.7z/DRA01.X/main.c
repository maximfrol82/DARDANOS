/**
  Section: Included Files
*/
#include "mcc_generated_files/system.h"
#include "mcc_generated_files/delay.h"
#include "mcc_generated_files/pin_manager.h"
#include "mcc_generated_files/switch1.h"
#include "mcc_generated_files/switch2.h"
#include "oled.h"
#include <stdlib.h>
#include "mcc_generated_files/spi2.h"
#include "depend.h"
#include "mcc_generated_files/memory/flash.h"
#include <limits.h>
////////////////////////////////////////////////////////////////////////////////
// Allocate and reserve a page of flash for this test to use.  The compiler/linker will reserve this for data and not place any code here.
static __prog__  uint8_t flashTestPage[FLASH_ERASE_PAGE_SIZE_IN_PC_UNITS] __attribute__((space(prog),aligned(FLASH_ERASE_PAGE_SIZE_IN_PC_UNITS)));
uint32_t flash_storage_address;
////////////////////////////////////////////////////////////////////////////////
int Kp = 220;
int Ki = 250;

uint8_t setter;
volatile int E, E1, E2, out_PID, cnt_PID;
volatile double pid_prop, L_int, L_mint, DiFF, tmpPID;
volatile double Int_sum = 0, Integ = 0, zero;
volatile int current_duty1, current_duty2;

int16_t MENU, old_menu;
bool Menu_changE, Timer_screen;
bool old_sig_C, sig_C, old_sig_R, sig_R, old_sig_L, sig_L;
bool flag_C, flag_R, flag_L, Timer_screen;
uint16_t cnt_Timer_screen;
//uint16_t cnt_load;
uint16_t FBmin;
uint16_t FBmax;
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
struct PARAM1
{
uint16_t Imax;
uint16_t KP;
uint16_t KI;
}mem;
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
extern uint16_t Rset, datFB, FB, Iset, datIset, I_load, Upower;
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//***************** prototype **************************************************
//------------------------------------------------------------------------------
void driver (int set);
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//******************************************************************************
//------------------------------------------------------------------------------
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void ISR_CN (void)
{
    sig_L = btn_C_GetValue() ?0:1;  
    sig_R = btn_R_GetValue() ?0:1;  
    sig_C = btn_L_GetValue() ?0:1; 
    HL_232_Toggle();   
    //////////////////////////////////////////////
    if(sig_C && !old_sig_C){flag_C = 1;}else{flag_C = 0;}
    if(sig_R && !old_sig_R){flag_R = 1;}else{flag_R = 0;}
    if(sig_L && !old_sig_L){flag_L = 1;}else{flag_L = 0;}
    //////////////////////////////////////////////    
    if(MENU < 8 && MENU > 0)
    {
    if(flag_R)MENU++;
    if(flag_L)MENU--;
    if(flag_C && MENU != 7)MENU = 1;
    if(MENU < 1)MENU = 7;
    if(MENU > 7)MENU = 1;
    if(flag_C && MENU == 7)MENU = 10;
    }
    //************************
    if(MENU <= 18 && MENU >= 10)
    {
    if(flag_R && !sig_C)MENU++;
    if(flag_L && !sig_C)MENU--;
    //if(flag_C && MENU != 7)MENU = 1;
    if(MENU < 10)MENU = 18;
    if(MENU > 18)MENU = 10;
    if(flag_C && MENU == 18)MENU = 1;
    if(flag_C && MENU == 16)WriteFlash();
    if(flag_C && MENU == 17)ReadFlash();
    //----------------------------------
    if(sig_C && MENU == 10){
        if(flag_R)mem.KP++;
        if(flag_L)mem.KP--;
        if(mem.KP < 1)mem.KP = 1;
        if(mem.KP > 999)mem.KP = 999;
    }
    //----------------------------------
    if(sig_C && MENU == 11){
        if(flag_R)mem.KI++;
        if(flag_L)mem.KI--;
        if(mem.KI < 1)mem.KI = 1;
        if(mem.KI > 999)mem.KI = 999;
    }//---------------------------------
    if(sig_C && MENU == 12){
        if(flag_R)mem.Imax+=10;
        if(flag_L)mem.Imax-=10;
        if(mem.Imax < 1000)mem.Imax = 1000;
        if(mem.Imax > 16000)mem.Imax = 16000;
    }//---------------------------------
    if(sig_C && MENU == 13){
        if(flag_R)FBmax = datFB;
        if(flag_L)FBmin = datFB;
    }//---------------------------------
    if(sig_C && MENU == 14){
        if(flag_R)FBmin++;
        if(flag_L)FBmin--;
        if(FBmin < 1)FBmin = 1;
        if(FBmin > 4095)FBmin = 4095;
    }//---------------------------------
    if(sig_C && MENU == 15){
        if(flag_R)FBmax++;
        if(flag_L)FBmax--;
        if(FBmax < 1)FBmax = 1;
        if(FBmax > 4095)FBmax = 4095;
    }//---------------------------------
    }//if(MENU <= 18 && MENU >= 10)
    //////////////////////////////////////////////  
    old_sig_C = sig_C;
    old_sig_R = sig_R;
    old_sig_L = sig_L;
}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
void ISR_TIMER5 (void)
{
//-----------------------------------------    
if(SWITCH1_IsPressed())
{
    setter = Iset;
}
else
{
    setter = Rset;
}
Kp = mem.KP;
Ki = mem.KI;
//-----------------------------------------
E1 =  setter - FB;
E = FB - setter;
//-----------------------------------------
pid_prop =(double)(E1) * (Kp * 0.01);//0.0001
//-----------------------------------------
L_int  = 100.0;
L_mint = -100.0;
//-----------------------------------------
Int_sum = (double)E1 * Ki * 0.000001;//0.0000001;
if(Int_sum > L_int) {Int_sum = L_int;}
if(Int_sum < L_mint){Int_sum = L_mint;}
//-----------------------------------------
Integ =  Integ + Int_sum;
//-----------------------------------------
if(Integ > L_int) {Integ = L_int;}
if(Integ < L_mint){Integ = L_mint;}
//-----------------------------------------
tmpPID = pid_prop + Integ;//
if(tmpPID > 100) {tmpPID = 100;}
if(tmpPID < -100){tmpPID = -100;}
//////////////////////////////////
out_PID = (int)tmpPID;
driver(out_PID);
//-----------------------------------------
cnt_Timer_screen++;
if(cnt_Timer_screen > 3000){Timer_screen = 1; cnt_Timer_screen = 0;}
}//
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
void PWM1_Set_Duty (int percent)
{
    int tmp;
    static int old_p;

    if(old_p != percent)
{
    if(percent > 100)percent = 100;
    if(percent <= 0)percent = 0;

    tmp = 2000 - 20 * percent;
    OC1_PrimaryValueSet(tmp);    
}
    old_p = percent;
}//
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
void PWM2_Set_Duty (int percent)
{
    int tmp;
    static int old_p;
if(old_p != percent)
{

    if(percent > 100)percent = 100;
    if(percent <= 0)percent = 0;

    tmp = 2000 - 20 * percent;
    OC2_PrimaryValueSet(tmp);    
}
    old_p = percent;
}//
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//******************************************************************************
void driver (int set)
{
     if(set == 0)
     {
     current_duty1 = 0;
     current_duty2 = 0;
     }
     if(set < 0)
     {
     current_duty1 = abs(set);
     current_duty2 = 0;
     }
     if(set > 0)
     {
     current_duty1 = 0;
     current_duty2 = abs(set);
     }
PWM1_Set_Duty(current_duty1);            // Set current duty for PWM1
PWM2_Set_Duty(current_duty2);            // Set current duty for PWM2
}//

////////////////////////////////////////////////////////////////////////////////
void SPI_Write(char byte) {
  char i;        
  dac_SCK_SetLow(); 
  for (i=0; i<8; i++) 
  {   
    DELAY_microseconds(50);
    if(byte & 0x80) dac_SDI_SetHigh(); else dac_SDI_SetLow(); 
    byte <<= 1;                                 
    DELAY_microseconds(50); 
    dac_SCK_SetHigh();         
    DELAY_microseconds(50);  
    dac_SCK_SetLow();         
  }
}//
////////////////////////////////////////////////////////////////////////////////
// DAC increments (0..100) --> output voltage (0..Vref)
// AO 0...5V from out 0..10V --> 0...2089
void DAC_Output(int valueDAC) {
  uint8_t temp;
  double dtmp;
  
  dac_CS_SetLow(); // Select DAC chip
  dtmp = 20.89 * valueDAC;
  if(dtmp > 2089)dtmp = 2089;
  if(dtmp < 1)dtmp = 1;  
  valueDAC = (int)dtmp;
  
  // Send High Byte
  temp = (valueDAC >> 8) & 0x0F;         // Store valueDAC[11..8] to temp[3..0]
  temp |= 0x30;                          // Define DAC setting, see MCP4921 datasheet
  SPI_Write(temp);                      // Send high byte via SPI
  // Send Low Byte
  temp = (uint8_t)valueDAC;                       // Store valueDAC[7..0] to temp[7..0]
  SPI_Write(temp);                      // Send low byte via SPI
  dac_CS_SetHigh();                       // Deselect DAC chip
}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
void screen1(void){
ClearLCD();
CursorLCD(0, 0);
StringLCD("SET POS ");
CursorLCD(1, 7);
StringLCD("%");
}
void screen2(void){
ClearLCD();
CursorLCD(0, 0);
StringLCD("FB POSIT");
CursorLCD(1, 7);
StringLCD("%");
}
void screen3(void){
ClearLCD();
CursorLCD(0, 0);
StringLCD("-PI OUT-");
CursorLCD(1, 7);
StringLCD("%");
}
void screen4(void){
ClearLCD();
CursorLCD(0, 0);
StringLCD("R setter");
CursorLCD(1, 7);
StringLCD("%");
}
void screen5(void){
ClearLCD();
CursorLCD(0, 0);
StringLCD("U power ");
CursorLCD(1, 4);
StringLCD("V*10");
}
void screen6(void){
ClearLCD();
CursorLCD(0, 0);
StringLCD("I LOAD  ");
CursorLCD(1, 6);
StringLCD("mA");
}
void screen7(void){
ClearLCD();
CursorLCD(0, 0);
StringLCD(" -menu- ");
CursorLCD(1, 0);
StringLCD("settings");
}
//------------------------------------------------------------------------------
void screen10(void){
ClearLCD();
CursorLCD(0, 0);
StringLCD("Kp -> PI");
}
void screen11(void){
ClearLCD();
CursorLCD(0, 0);
StringLCD("Ki -> PI");
}
void screen12(void){
ClearLCD();
CursorLCD(0, 0);
StringLCD("MAX LOAD");
CursorLCD(1, 6);
StringLCD("mA");
}
void screen13(void){
ClearLCD();
CursorLCD(0, 0);
StringLCD("-FB ADC-");
}
void screen14(void){
ClearLCD();
CursorLCD(0, 0);
StringLCD(">FB min<");
}
void screen15(void){
ClearLCD();
CursorLCD(0, 0);
StringLCD("<FB max>");
}
void screen16(void){
ClearLCD();
CursorLCD(0, 0);
StringLCD("save to ");
CursorLCD(1,0);
StringLCD(" memory ");
}
void screen17(void){
ClearLCD();
CursorLCD(0,0);
StringLCD("  read  ");
CursorLCD(1, 0);
StringLCD(" memory ");
}
void screen18(void){
ClearLCD();
CursorLCD(0, 0);
StringLCD("back to ");
CursorLCD(1, 0);
StringLCD(" work-->");
}
//******************************************************************************
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
void cikl_MENU(void){
if (old_menu != MENU){Menu_changE = 1;}else{Menu_changE = 0;}
old_menu = MENU;
if(Menu_changE){
    HL_CAN_Toggle();
if (MENU == 1){screen1();}
if (MENU == 2){screen2();}
if (MENU == 3){screen3();}
if (MENU == 4){screen4();}
if (MENU == 5){screen5();}
if (MENU == 6){screen6();}
if (MENU == 7){screen7();}
///////////////////////////////
if (MENU == 10){screen10();}
if (MENU == 11){screen11();}
if (MENU == 12){screen12();}
if (MENU == 13){screen13();}
if (MENU == 14){screen14();}
if (MENU == 15){screen15();}
if (MENU == 16){screen16();} 
if (MENU == 17){screen17();}
if (MENU == 18){screen18();} 
}//menu change
}//
////////////////////////////////////////////////////////////////////////////////
//******************************************************************************
void Draw_data (void)
{
static char *syswrng1, *syswrng2, *syswrng3, *syswrng4;
///////////////////////////////////////
if(MENU == 1){
pprint3(Iset,1,0);
}//
if(MENU == 2){
pprint3(FB,1,0);
}//
if(MENU == 3){
printINT(out_PID,1,0);
}//
if(MENU == 4){
pprint3(Rset,1,0);
}//
if(MENU == 5){
pprint3(Upower,1,0);
}//
if(MENU == 6){
pprint4(I_load,1,0);
}//
//*********************
if(MENU == 10){
pprint4(mem.KP,1,2);
}//
if(MENU == 11){
pprint4(mem.KI,1,2);
}//
if(MENU == 12){
pprint4(mem.Imax,1,1);
}//
if(MENU == 13){
pprint4(datFB, 1, 1);
}//
if(MENU == 14){
pprint4(FBmin, 1, 1);
}//
if(MENU == 15){
pprint4(FBmax, 1, 1);
}//
///////////////////////////////////////
}//
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
void WriteFlash(void)
{
    bool result;
    
    FLASH_Unlock(FLASH_UNLOCK_KEY);

    result = FLASH_ErasePage(flash_storage_address);

    // For this product we must write two adjacent words at a one time.
    FLASH_WriteDoubleWord16(flash_storage_address,       mem.KP,    mem.KP);
    FLASH_WriteDoubleWord16(flash_storage_address + 4U,  mem.KI,    mem.KI);
    FLASH_WriteDoubleWord16(flash_storage_address + 8U,  mem.Imax,  mem.Imax);
    FLASH_WriteDoubleWord16(flash_storage_address + 12U, FBmin, FBmin);
    FLASH_WriteDoubleWord16(flash_storage_address + 16U, FBmax, FBmax);

    // Clear Key for NVM Commands so accidental call to flash routines will not corrupt flash
    FLASH_Lock();
}//
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
void ReadFlash(void)
{
mem.KP    = FLASH_ReadWord16(flash_storage_address);
mem.KI    = FLASH_ReadWord16(flash_storage_address + 4U);
mem.Imax  = FLASH_ReadWord16(flash_storage_address + 8U);
FBmin = FLASH_ReadWord16(flash_storage_address + 12U);
FBmax = FLASH_ReadWord16(flash_storage_address + 16U);
}//
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*
                         Main application
 */
////////////////////////////////////////////////////////////////////////////////
int main(void)
{
    // initialize the device
    SYSTEM_Initialize();
    TMR5_SetInterruptHandler(ISR_TIMER5);
    CN_SetInterruptHandler(ISR_CN);
    TMR5_Start();
    OLED_init();

    OC1_SecondaryValueSet(2000);
    OC2_SecondaryValueSet(2000);
    OC1_PrimaryValueSet(2000); 
    OC2_PrimaryValueSet(2000);
    OC1_Start();
    OC2_Start();
////////////////////////    
    MENU = 1;
    old_menu = 0;
////////////////////////
flash_storage_address = FLASH_GetErasePageAddress((uint32_t)&flashTestPage[0]);
ReadFlash();
//==============================================================================
    while (1)
    {
        // Add your application code
        DELAY_milliseconds(5);
////////////////////////////////////////////
        cikl_MENU();
        if(Timer_screen){
            Draw_data();
            Timer_screen = 0;
            DAC_Output(FB);
        }
////////////////////////////////////////////
    if(I_load > mem.Imax)
    {
        HL_RED_SetHigh();
    }
    else
    {
        HL_RED_SetLow();
    }
        
    if(SWITCH2_IsPressed()){
        drv_DIS_SetHigh();
    }
    else
    {
        drv_DIS_SetLow();
    }
////////////////////////////////////////////
    }//while
    return 1;
}//
//==============================================================================
/**
 End of File
*/
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
